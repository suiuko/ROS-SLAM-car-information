// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__PERSON_HPP_
#define PKG_INTERFACES__MSG__PERSON_HPP_

#include "pkg_interfaces/msg/detail/person__struct.hpp"
#include "pkg_interfaces/msg/detail/person__builder.hpp"
#include "pkg_interfaces/msg/detail/person__traits.hpp"

#endif  // PKG_INTERFACES__MSG__PERSON_HPP_
