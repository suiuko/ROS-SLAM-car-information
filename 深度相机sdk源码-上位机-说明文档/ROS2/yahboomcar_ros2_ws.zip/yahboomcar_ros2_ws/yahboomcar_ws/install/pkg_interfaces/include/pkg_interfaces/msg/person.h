// generated from rosidl_generator_c/resource/idl.h.em
// with input from pkg_interfaces:msg/Person.idl
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__MSG__PERSON_H_
#define PKG_INTERFACES__MSG__PERSON_H_

#include "pkg_interfaces/msg/detail/person__struct.h"
#include "pkg_interfaces/msg/detail/person__functions.h"
#include "pkg_interfaces/msg/detail/person__type_support.h"

#endif  // PKG_INTERFACES__MSG__PERSON_H_
