// generated from rosidl_generator_c/resource/idl.h.em
// with input from pkg_interfaces:srv/Add.idl
// generated code does not contain a copyright notice

#ifndef PKG_INTERFACES__SRV__ADD_H_
#define PKG_INTERFACES__SRV__ADD_H_

#include "pkg_interfaces/srv/detail/add__struct.h"
#include "pkg_interfaces/srv/detail/add__functions.h"
#include "pkg_interfaces/srv/detail/add__type_support.h"

#endif  // PKG_INTERFACES__SRV__ADD_H_
